import org.apache.spark.sql._
import org.apache.spark.sql.functions._

object sparkScala {
}

/**
  /*case class WebsiteLog(rowKey:String="",
                        sessionId:String="",
                        ipAddress:String="",
                        timestamp:String="",
                        loadTimestamp:String="",
                        userId:String="",
                        url:String=""){
  }*/


  case class FactTable(UserId: Int, event_date: String, web_pageId: Int)

  case class LookUpTable(web_pageId: Int, webPage_Type: String)

  /*

'news, movies' 'fre, dur' '365, 730, 1460, 2920' '12/10/2019'
   */

  def main(args: Array[String]) {
    val file = args(0)

    /*val pagetype = this.args(1).split(" ")  //'news, movies'
  val metrictype = this.args(2).split(" ")  // 'fre, dur'
  val timewindow = this.args(3).split(" ")  // '365, 730, 1460, 2920'
  val dateofreference = this.args(4) // '12/10/2019'

  */
    val pageType = "news, movies".trim.split(",").map(_.trim) //'news, movies'
    val metricType = "fre, dur".split(",".trim) // 'fre, dur'
    val timeWindow = "365, 730, 1460, 2920".trim.split(",") // '365, 730, 1460, 2920'
    val dateOfReference = "12/10/2019"

    //pageType.toList.foreach(println(_))


    //pageview_<pagetype>_<metrictype>_<timewindow>

   // val metricList = pageType.flatMap(m1 => metricType.flatMap(m2 => timeWindow.map(m3 => "pageview" + '_' + m1.trim + '_' + m2.trim + '_' + m3.trim))).toList

    //metricList.foreach(println(_))


    val spark = SparkSession.builder()
      .appName("Spark Schema Demo")
      .master("local[3]")
      .getOrCreate()

    import spark.implicits._
    val inputData = spark.read.format("csv").option("delimiter", "\t")
                      //    .option("header", "true")
      .load("/Users/gargi/Documents/InterviewQuestions/SparkScalaTest/src/main/resources/fact.csv").toDF()

    val lookUpData = spark.read.format("csv").option("delimiter", "\t")
                    .load("/Users/gargi/Documents/InterviewQuestions/SparkScalaTest/src/main/resources/lookup.csv").toDF()

    //pageview_news_dur	pageview_news_fre_365	pageview_news_fre_730

   val inputDataDS =  inputData.map( r => FactTable(r.getAs(0.toInt), r.getAs[String](1), r.getAs(2.toInt)))
    val lookUpDS =  lookUpData.map( r => LookUpTable(r.getAs(0.toInt), r.getAs[String](1)))

    lookUpDS.printSchema()
    inputDataDS.printSchema()

  val changedInput = inputDataDS.join(lookUpDS,inputDataDS("web_pageId") === lookUpDS("web_pageId") ,"inner")
      .select($"UserId",$"event_date",$"webPage_Type")

    // group by user id
    // group by web page type
    // find last 365 days data
    // find last 720 days data


   // pageType.flatMap(m1 => metricType.flatMap(m2 => timeWindow.map(m3 => "pageview" + '_' + m1.trim + '_' + m2.trim + '_' + m3.trim)))

    // for frequency for each time window
    var outList : List[String] = Nil

    changedInput.printSchema()


    changedInput.withColumn("newCol",to_date($"event_date") ).withColumn("todayDate",current_date()).show(5)
  println("AFterrr")
    changedInput.printSchema()
   // pageType.foreach { pType =>
   //   timeWindow.foreach { timeX =>
    //    val columName = "pageview_" + "news" + "_" + "freq" + "_" + timeX
     //  changedInput.filter($"webPage_Type" === "news").filter((to_date($"event_date") - current_date()) <= timeX)
      //  .groupBy($"userId").agg(count("*").as(columName))
     // }
   // }
  /*  val exSummaryDF = invoiceDF
      .withColumn("InvoiceDate", to_date(col("InvoiceDate"), "dd-MM-yyyy H.mm"))
      .where("year(InvoiceDate) == 2010")
      .withColumn("WeekNumber", weekofyear(col("InvoiceDate")))
      .groupBy("Country", "WeekNumber")
      .agg(NumInvoices, TotalQuantity, InvoiceValue)
    }*/

    /**
     * root
     * |-- UserId: integer (nullable = false)
     * |-- event_date: string (nullable = true)
     * |-- web_pageId: integer (nullable = false)
     * |-- web_pageId: integer (nullable = false)
     * |-- webPage_Type: string (nullable = true)
     */




  }
}


/***
 **
 * val arr1: Array[String] = Array("a", "b", "c")
 * val arr2: Array[String] = Array("d", "e")
 * val arr3: Array[String] = Array("f", "g", "h", "i")
 * *
 * val result: List[String] = Arrays.stream(arr1).flatMap((s1: String) => Arrays.stream(arr2).flatMap((s2: String) => Arrays.stream(arr3).map((s3: String) => s1 + s2 + s3))).collect(Collectors.toList)
 * *
 *System.out.println(result)
 *
 *
 *

//val data=inputData.map{s => s.
     // val fields= s.split("\t")
     // WebsiteLog(fields(0),fields(1),fields(2),fields(3),fields(4),fields(5),fields(6))
   // })




    // def createMetricList(pagetype: Array[String], metrictype: Array[String], timewindow: Array[String]) = {
    /*  List<String> result = Arrays.stream(arr1).flatMap(s1 -> Arrays.stream(arr2).flatMap(s2 -> Arrays.stream(arr3)
          .map(s3 -> s1 + s2 + s3)))
      .collect(Collectors.toList()); */


    //createMetricList(pagetype,metrictype,timewindow)
 **/
 **/