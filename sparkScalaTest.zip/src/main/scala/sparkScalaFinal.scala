import java.text.SimpleDateFormat

import org.apache.spark.sql._
import org.apache.spark.sql.expressions._
import org.apache.spark.sql.functions._

import scala.collection.mutable.ListBuffer



object sparkScalaFinal {

    case class FactTable(UserId: Int, event_date: String, web_pageId: Int)
    case class LookUpTable(web_pageId: Int, webPage_Type: String)

    def main(args: Array[String]) {

      //pageview_<pagetype>_<metrictype>_<timewindow>

      val spark = SparkSession.builder()
        .appName("Spark Schema Demo")
        .master("local[3]")
        .getOrCreate()

      spark.sparkContext.setLogLevel("WARN")
      import spark.implicits._
      val inputData = spark.read.format("csv").option("delimiter", "\t").option("header","true")
        .load("/Users/gargi/Documents/InterviewQuestions/SparkScalaTest/src/main/resources/fact.csv")

      val lookUpData = spark.read.format("csv").option("delimiter", "\t").option("header","true")
        .load("/Users/gargi/Documents/InterviewQuestions/SparkScalaTest/src/main/resources/lookup.csv")


     val inputDataDS =  inputData.map( r => //r.getAs[String](0).toInt)
                                  FactTable(r.getAs[String](0).toInt, r.getAs[String](1),r.getAs[String](2).toInt))

      val lookUpDS =  lookUpData.map( r => LookUpTable(r.getAs[String](0).toInt, r.getAs[String](1)))


     val changedInput = inputDataDS.join(lookUpDS,inputDataDS("web_pageId") === lookUpDS("web_pageId") ,"inner")
        .select($"UserId",$"event_date",$"webPage_Type")

      changedInput.printSchema()

      changedInput.show(5)

     val dateChangedInputDF =  changedInput
                          .withColumn("newCol",to_date(to_timestamp($"event_date", "dd/MM/yyyy HH:mm"),"dd-MMM-yyyy"))


      val pageType = "news, movies".trim.split(",").map(_.trim) //'news, movies'
      val metricType = "fre".split(",".trim) // 'fre, dur'
      val timeWindow = "365, 730, 1460, 2920".trim.split(",") // '365, 730, 1460, 2920'
      val dateOfReference = "12/10/2019"

      dateChangedInputDF.show(5)
      val metricList = pageType.flatMap(m1 => metricType.flatMap(m2 => timeWindow
        .map(m3 => "pageview" + '_' + m1.trim + '_' + m2.trim + '_' + m3.trim))).toList

      import org.apache.spark.sql.types._

    /*  val metricList1 = "UserId" :: metricList
      val fields = metricList1.map( f => StructField(f,StringType,nullable=true))
      val customSchema = StructType(fields)
      val resultDF:DataFrame = spark.createDataFrame(spark.sparkContext.emptyRDD[Row],customSchema)
*/
    //  resultDF.printSchema()

      var dataframeList: ListBuffer[org.apache.spark.sql.DataFrame] = ListBuffer()

   /*   dateChangedInputDF.groupBy($"userId")foreach(x => {
        val tempDF = df.filter(col("id") === x)
        dataframeList += tempDF
      })*/

      dateChangedInputDF.printSchema()
  val result =     pageType.foreach { pType =>
        timeWindow.foreach { timeX =>

          val columnName = "pageview_" + pType.trim + "_" + "fre" + "_" + timeX.trim
          println(" Showing Stats for ", columnName)
       val tempDF =  dateChangedInputDF.filter($"webPage_Type" === pType)
            .filter(datediff($"newCol", current_date()) <= timeX)
            .withColumn(columnName,count("*") over Window.partitionBy($"userId").orderBy($"event_date"))
            .drop($"webPage_Type").drop($"newCol").drop($"event_date")
         //   .groupBy($"userId")
           // .agg(count("*").as(columnName))


          dataframeList += tempDF
           }

      }
/*
      val rfm=recent.join(frequent).join(duration).map(i=>
        RFM(i._1,i._2._1._1,i._2._1._2,i._2._2)
      ).sortBy(x=>(x.recency,x.frequency,x.duration),false)
  */
      println("before")
  //    resultDF.show()

   /*   val resultDF1 = dataframeList.head

     for (tempDF1 <- dataframeList) {

      // tempDF1.show()
  //  val r =   resultDF1.join(tempDF1,resultDF1("UserId") === tempDF1("UserId"),"full_outer")
//r.show()

      }*/

   //  dataframeList.reduce(_ unionAll _).show()

   dataframeList.reduce(_.join(_, Seq("UserId"),"outer"))
            .na.fill("") //.show(50)

      println("after")
  //    resultDF.show()
     // dateChangedInputDF.printSchema()


     // val r = spark.sql("Select * from pageview_news_freq_ 2920")

  val result2=  dateChangedInputDF
                  .withColumn("rn", row_number() over Window.partitionBy("userId","webPage_Type").orderBy($"event_date".desc))
                .filter($"rn" === 1).drop($"rn")
              .withColumn("dateOfRef",to_date(to_timestamp(lit(dateOfReference), "dd/MM/yyyy"),"dd-MMM-yyyy"))
             .withColumn("pageview_dur",datediff($"event_date",$"dateOfRef"))
    .       show()


    //.withColumn("newCol",to_date(to_timestamp($"event_date", "dd/MM/yyyy HH:mm"),"dd-MMM-yyyy"))



    }


}




/*  println("entering")
  val values = List(List("1", "One") ,List("2", "Two") ,List("3", "Three"),List("4","4")).map(x =>(x(0), x(1)))
val values1 = List("hello","value").map{Tuple1(_)}
  import spark.implicits._

*/